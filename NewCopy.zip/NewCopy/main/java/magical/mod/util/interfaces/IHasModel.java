package magical.mod.util.interfaces;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public interface IHasModel {
	
	public void registerModels();

	
}
