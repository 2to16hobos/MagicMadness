package magical.mod.util;

public class References {

	public static final String MODID = "mm";
	public static final String NAME = "Magical Madness";
	public static final String VERSION = "0.1";
	public static final String CLIENT = "magical.mod.proxy.ClientProxy";
	public static final String COMMON = "magical.mod.proxy.CommonProxy";

}
